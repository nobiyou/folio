/**
 * Folio Theme Customizer Preview
 *
 * @package Folio
 */

(function($) {
    'use strict';

    // 注意：社交链接设置已移至主题设置页面（外观 > 主题设置 > 社交链接）
    // Customizer 中的社交链接预览功能已移除
    
    // 注意：页脚设置已移至主题设置页面（外观 > 主题设置 > 常规设置）
    // Customizer 中的页脚设置预览功能已移除

})(jQuery);
